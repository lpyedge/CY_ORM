﻿namespace DapperExtensions.Test.Data
{
    public class Multikey
    {
        public long Key1 { get; set; } 
        public string Key2 { get; set; }
        public string Value { get; set; }
    }
}