﻿using System;

namespace DapperExtensions.Test.Data
{
    class Animal
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
