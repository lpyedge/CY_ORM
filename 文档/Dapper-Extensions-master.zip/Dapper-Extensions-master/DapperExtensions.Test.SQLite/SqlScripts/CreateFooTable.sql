﻿CREATE TABLE FooTable (
    FooId INT IDENTITY(1,1) PRIMARY KEY,
    [First] NVARCHAR(50),
    [Last] NVARCHAR(50),
    BirthDate DATETIME
)