﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DapperExtensions.Test.Data
{
    class Car
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
