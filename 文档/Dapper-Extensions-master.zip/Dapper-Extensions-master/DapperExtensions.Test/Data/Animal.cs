﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DapperExtensions.Test.Data
{
    class Animal
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
